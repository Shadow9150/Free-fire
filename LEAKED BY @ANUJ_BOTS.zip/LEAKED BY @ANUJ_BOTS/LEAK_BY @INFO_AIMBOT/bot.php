<?php

$token = "7692165780:AAHQmjjiCRrvWunZ-6WwWVzYI-KI7Ws3h50";
$data = [
    'text' => $msg,
    'chat_id' => '5582611779'
];

?>